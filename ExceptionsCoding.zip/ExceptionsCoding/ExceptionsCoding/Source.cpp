#include <iostream>

// custom exception class
class CustomException : public std::exception {
public:
    const char* what() {
        return "CUSTOM EXCEPTION CAUGHT";
    }
};


bool do_even_more_custom_application_logic()
{
    std::cout << "Running Even More Custom Application Logic." << std::endl;

    // throws invalid argument exception
    throw std::invalid_argument("EXCEPTION FOR EVEN MORE CUSTOM APPLICATION LOGIC CAUGHT");

    return true;
}
void do_custom_application_logic()
{

    std::cout << "Running Custom Application Logic." << std::endl;

    // catch exception thrown by 'do_even_more_custom_application_logic' and continue processing
    try {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (std::exception e) {
        std::cout << "ERROR - " << e.what() << std::endl;
    }

    // throw custom exception derived from std::exception
    throw CustomException();

    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{

    // throw exception to deal with divide by zero errors
    throw std::runtime_error("RUNTIME ERROR CAUGHT");

    return (num / den);
}

void do_division() noexcept
{

    // catch exception thrown by 'divide'
    try {

        float numerator = 10.0f;
        float denominator = 0;

        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (std::runtime_error e) {
        std::cout << "ERROR - " << e.what() << std::endl;
    }
}

int main()
{
    try {
        std::cout << "Exceptions Tests!" << std::endl;

        do_division();
        do_custom_application_logic();

    // catch custom exception, std::exception, and uncaught exception 
    }
    catch (CustomException e) {
        std::cout << "ERROR - " << e.what() << std::endl;
    }
    catch (std::exception e) {
        std::cout << "ERROR - " << e.what() << std::endl;
    }
    catch (...) {
        std::cout << "ERROR - UNCAUGHT EXCEPTION" << std::endl;
    }
}
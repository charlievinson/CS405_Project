// Uncomment the next line to use precompiled headers
#include "pch.h"
// uncomment the next line if you do not use precompiled headers
//#include "gtest/gtest.h"
//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        //  initialize random seed
        srand(time(nullptr));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
    // create a smart point to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    { // create a new collection to be used in the test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    { //  erase all elements in the collection, if any remain
        collection->clear();
        // free the pointer
        collection.reset(nullptr);
    }

    // helper function to add random values from 0 to 99 count times to the collection
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    // is the collection created
    ASSERT_TRUE(collection);

    // if empty, the size must be 0
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
//TEST_F(CollectionTest, AlwaysFail)
//{
//    FAIL();
//}

// Test adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
    // is the collection empty?
    // if empty, the size must be 0
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);

    add_entries(1);

    // is the collection still empty?
    // if not empty, what must the size be?
    ASSERT_FALSE(collection->empty());
    ASSERT_EQ(collection->size(), 1);
}

// Test adding five values to collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    // is the collection empty?
    // if empty, the size must be 0
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);

    add_entries(5);

    // is the collection still empty?
    // if not empty, what must the size be?
    ASSERT_FALSE(collection->empty());
    ASSERT_EQ(collection->size(), 5);
}

// Test that max size is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, MaxSizeIsGreaterThanOrEqualToEntries) {

    // is the collection empty?
    // if empty, the size must be 0
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);

    // verify max size is greater than 0
    ASSERT_TRUE(collection->max_size() >= collection->size());

    // add entry and verify size is greater than 1
    add_entries(1);
    ASSERT_EQ(collection->size(), 1);
    ASSERT_TRUE(collection->max_size() >= collection->size());

    // add 4 entries and verify size is greater than 5
    add_entries(4);
    ASSERT_EQ(collection->size(), 5);
    ASSERT_TRUE(collection->max_size() >= collection->size());

    // add 5 entries and verify size is greater than 10
    add_entries(5);
    ASSERT_EQ(collection->size(), 10);
    ASSERT_TRUE(collection->max_size() >= collection->size());
}

// Test that capacity is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, CapacityIsGreaterThanOrEqualToEntries) {

    // is the collection empty?
    // if empty, the size must be 0
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);

    // verify max size is greater than 0
    ASSERT_TRUE(collection->capacity() >= collection->size());

    // add entry and verify size is greater than 1
    add_entries(1);
    ASSERT_EQ(collection->size(), 1);
    ASSERT_TRUE(collection->capacity() >= collection->size());

    // add 4 entries and verify size is greater than 5
    add_entries(4);
    ASSERT_EQ(collection->size(), 5);
    ASSERT_TRUE(collection->capacity() >= collection->size());

    // add 5 entries and verify size is greater than 10
    add_entries(5);
    ASSERT_EQ(collection->size(), 10);
    ASSERT_TRUE(collection->capacity() >= collection->size());
}

// Test that resizing increases the collection
TEST_F(CollectionTest, ResizingIncreasesCollection) {

    // is the collection empty?
    // if empty, the size must be 0
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);

    // resize to increase collection and verify new size
    collection->resize(10);
    ASSERT_EQ(collection->size(), 10);
}

// Test that resizing decreases the collection
TEST_F(CollectionTest, ResizingDecreasesCollection) {
    // is the collection empty?
    // if empty, the size must be 0
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);

    // add entries and verify new size
    add_entries(10);
    EXPECT_EQ(collection->size(), 10);

    // resize to decrease collection and verify new size
    collection->resize(2);
    ASSERT_EQ(collection->size(), 2);
}

// Test that resizing decreases the collection to zero
TEST_F(CollectionTest, ResizingDecreasesCollectionToZero) {
    // is the collection empty?
    // if empty, the size must be 0
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);

    // add entries and verify new size
    add_entries(10);
    EXPECT_EQ(collection->size(), 10);

    // resize to decrease collection and verify new size
    collection->resize(0);
    ASSERT_EQ(collection->size(), 0);
}

// Test that clear erases the collection
TEST_F(CollectionTest, ClearFunctionErasesCollection) {

    // add 5 entries to collection and verify size
    add_entries(5);
    EXPECT_EQ(collection->size(), 5);

    // clear collection and verify it is empty
    collection->clear();
    ASSERT_TRUE(collection->empty());
}

// Test that erase(begin,end) erases the collection
TEST_F(CollectionTest, EraseFunctionErasesCollection) {

    // add 5 entries to collection and verify size
    add_entries(5);
    EXPECT_EQ(collection->size(), 5);

    // erase collection and verify it is empty
    collection->erase(collection->begin(), collection->end());
    ASSERT_TRUE(collection->empty());
}

// Test that reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest, ReserveIncreasesCapacityNotSize) {

    // add 5 entries to collection and verify size
    add_entries(5);
    EXPECT_EQ(collection->size(), 5);

    // hold initial capacity of collection
    int initialCapacity = collection->capacity();

    // reserve space in collection
    collection->reserve(50);

    // verify capacity has increased and size remains the same
    ASSERT_TRUE(collection->capacity() > initialCapacity);
    ASSERT_EQ(collection->size(), 5);
}

// Test that the std::out_of_range exception is thrown when calling at() with an index out of bounds
TEST_F(CollectionTest, ThrowsOutOfRangeExceptionWhenIndexOutOfRange) {

    // add 5 entries to collection and verify size
    add_entries(5);
    EXPECT_EQ(collection->size(), 5);

    // verify that attempting to access 50th element throws out of range exception
    ASSERT_THROW(collection->at(50), std::out_of_range);
}

// Test that elements in collection are integers
TEST_F(CollectionTest, ElementsInCollectionAreIntegers) {

    // add entry to collection and verify size
    add_entries(1);
    EXPECT_EQ(collection->size(), 1);

    // create strings holding value returned by typeid on element in collection and expected return value
    std::string elementType = typeid(collection->at(0)).name();
    std::string expectedElementType = "int";

    // verify strings are equal
    ASSERT_EQ(elementType, expectedElementType);
}

// Test that exception is thrown when attempting to access element in empty array
TEST_F(CollectionTest, ThrowsExceptionWhenAccessingElementInEmptyCollection) {

    // verify that collection is empty
    EXPECT_TRUE(collection->empty());

    // verify that an exception is thrown when attempting to access element in empty collection
    ASSERT_ANY_THROW(collection->at(1));
}